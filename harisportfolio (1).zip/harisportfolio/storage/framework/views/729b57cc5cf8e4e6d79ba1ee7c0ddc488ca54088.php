

<?php $__env->startSection('content'); ?>

<div class="scroll-up-btn">
    <i class="fas fa-angle-up"></i>
</div>
<nav class="navbar">
    <div class="max-width">
        <div class="logo"><a href="#">H A R<span> I S.</span></a></div>
        <ul class="menu">
            <li><a href="#home" class="menu-btn">Home</a></li>
            <li><a href="#about" class="menu-btn">About</a></li>
            <li><a href="#services" class="menu-btn">Services</a></li>
            <li><a href="#skills" class="menu-btn">Skills</a></li>
            <li><a href="#teams" class="menu-btn">Teams</a></li>
            <li><a href="#contact" class="menu-btn">Contact</a></li>
        </ul>
        <div class="menu-btn">
            <i class="fas fa-bars"></i>
        </div>
    </div>
</nav>


<section class="home" id="home">
    <div class="max-width">
        <div class="home-content">
            <div class="text-1">Hello, my name is</div>
            <div class="text-2">Haris Baba</div>
            <div class="text-3">And I'm a <span class="typing"></span></div>
            <a href="#">Hire me</a>
        </div>
    </div>
</section>


<section class="about" id="about">
    <div class="max-width">
        <h2 class="title">About me</h2>
        <div class="about-content">
            <div class="column left">
                <img src="<?php echo e(asset('images/WhatsApp Image 2022-07-13 at 1.40.04 PM.jpeg')); ?>" alt="">
            </div>
            <div class="column right">
                <div class="text">I'm Haris Baba and I'm a <span class="typing-2"></span></div>
                <p>Building unforgettable brands through design and technology-oriented solutions, I stands out to be a digitally creative IT agency which primarily works to keep concept and strategy gelled in together.I'm working with a team of highly creative individuals who work day and night to bring original ideasto life with unmatched solutions that help capture an audience for you in this highly competitive digital world. Our experts deliver complete digital solutions to resolve intricate problems for our clients. We trust in long-term results and that’s why we’ve brought together a team of digital experts with an artistic edge, who are able to use latest digital tools and techniques to produce innovative approaches.</p>
                <a href="#">Download CV</a>
            </div>
        </div>
    </div>
</section>

<!-- services section start -->
<section class="services" id="services">
    <div class="max-width">
        <h2 class="title">My services</h2>
        <div class="serv-content">
            <div class="card">
                <div class="box">
                    <i class="fas fa-paint-brush"></i>
                    <div class="text">Web Design</div>
                    <p>Every project needs to start with a vision and a strategy and, then built step by step. Each step of our website development process has been formulated to drive your business towards its vision. our vision is clear to give your website best.

                    </p>
                </div>
            </div>
            <div class="card">
                <div class="box">
                    <i class="fas fa-chart-line"></i>
                    <div class="text">Digital Marketing </div>
                    <p>Our clients trust us with huge media budgets to deliver them results online. With years of experience in running marketing campaigns across paid, organic (SEO) and social channels, we make sure to bring commercial success every time for our customers.</p>
                </div>
            </div>
            <div class="card">
                <div class="box">
                    <i class="fas fa-code"></i>
                    <div class="text">UI/UX</div>
                    <p>Digital vision is not complete without a great design. Be it development or digital marketing, our design services are entrenched into our solutions. We put user needs at the center of our efforts focusing on delectable experiences.</p>
                </div>
            </div>
           </div>
        </div>
    </div>
</section>

<!-- skills section start -->
<section class="skills" id="skills">
    <div class="max-width">
        <h2 class="title">My skills</h2>
        <div class="skills-content">
            <div class="column left">
                <div class="text">My creative skills & experiences.</div>
                <p>I have focus on creating sector leading websites, e-commerce solutions, digital marketing and much more. We don’t run a production line or put time limits on creativity. Backed by a deep insight into your world, our creative design and development teams have the freedom to deliver the very best designing experiences for today and tomorrow. <br>
                    <br>



                    I provide result-oriented services such as Digital Marketing, Web design, App UI design and much more. Reach out for results that can give your business a boost and drive more leads, increase your reach, improve your website experience, engage your target audience and connect with your clients.</p>
                <a href="#">Read more</a>
            </div>
            <div class="column right">
                <div class="bars">
                    <div class="info">
                        <span>HTML</span>
                        <span>100%</span>
                    </div>
                    <div class="line html"></div>
                </div>
                <div class="bars">
                    <div class="info">
                        <span>CSS</span>
                        <span>100%</span>
                    </div>
                    <div class="line css"></div>
                </div>
                <div class="bars">
                    <div class="info">
                        <span>BOOT STRAP</span>
                        <span>100%</span>
                    </div>
                    <div class="line js"></div>
                </div>
                <div class="bars">
                    <div class="info">
                        <span>JavaScript</span>
                        <span>100%</span>
                    </div>
                    <div class="line php"></div>
                </div>
                
            </div>
        </div>
    </div>
</section>

<!-- teams section start -->
<section class="teams" id="teams">
    <div class="max-width">
        <h2 class="title">My teams</h2>
        <div class="carousel owl-carousel">
            <div class="card">
                <div class="box">
                    <img src="images/profile-1.jpeg" alt="">
                    <div class="text">Hamza Shahid</div>

                </div>
            </div>
            <div class="card">
                <div class="box">
                    <img src="images/abdullah.jpg" alt="">
                    <div class="text">Abdullah Akram</div>

                </div>
            </div>
            <div class="card">
                <div class="box">
                    <img src="images/haris.jpg" alt="">
                    <div class="text">Haris Baba</div>

                </div>
            </div>
            
        </div>
    </div>
</section>

<!-- contact section start -->
<section class="contact" id="contact">
    <div class="max-width">
        <h2 class="title">Contact me</h2>
        <div class="contact-content">
            <div class="column left">
                <div class="text">Get in Touch</div>
                <p>Send us a note and we will get back to you as soon as we can. We look forward to hearing from you.</p>
                <div class="icons">
                    <div class="row">
                        <i class="fas fa-user"></i>
                        <div class="info">
                            <div class="head">Name</div>
                            <div class="sub-title">Haris Baba</div>
                        </div>
                    </div>
                    <div class="row">
                        <i class="fas fa-map-marker-alt"></i>
                        <div class="info">
                            <div class="head">Address</div>
                            <div class="sub-title">P.E.C.H.S. Block II</div>
                        </div>
                    </div>
                    <div class="row">
                        <i class="fas fa-envelope"></i>
                        <div class="info">
                            <div class="head">Email</div>
                            <div class="sub-title">Harisrizwan110@gmail.com</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="column right">
                <div class="text">Message me</div>
                <form action="<?php echo e(route('contactform')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="fields">
                        <div class="field name">
                            <input type="text" name="name" placeholder="Name" required>
                        </div>
                        <div class="field email">
                            <input type="email" name="email" placeholder="Email" required>
                        </div>
                    </div>
                    <div class="field">
                        <input type="text" name="subject" placeholder="Subject" required>
                    </div>
                    <div class="field textarea">
                        <textarea cols="30" name="message" rows="10" placeholder="Message.." required></textarea>
                    </div>
                    <div class="button-area">
                        <button type="submit">Send message</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- footer section start -->
<footer>
    <span>Created By Haris Baba</a> | <span class="far fa-copyright"></span> 2022 All rights reserved.</span>
</footer>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\software house work\harisportfolio\resources\views/main.blade.php ENDPATH**/ ?>