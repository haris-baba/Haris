<?php

namespace App\Http\Controllers;

use App\Mail\Contact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ContactController extends Controller
{
    public function contactform(Request $request){

        $this->validate($request,[
            'name' => 'required',
            'email' => 'required|email',
            'subject' => 'required',
            'message' => 'required',
           
        ]);

        $data = array(
            'name' => $request->name,
            'email' => $request->email,
            'subject' => $request->subject,
            'message' => $request->message
        );
        
        //dd($request->all());
       
                   
        //array_push($all_requ,$data);  
        ini_set('max_execution_time', '0');
        Mail::to('harisrizwan110@gmail.com')->send(new Contact($data));
        
         
         return back()->with('success', 'Thanks for contacting Us!');

    }
}
